#!/bin/bash

# Link to the binary
rm -f /usr/local/bin/messengerfordesktop

# Launcher files
rm -f /usr/share/applications/messengerfordesktop.desktop

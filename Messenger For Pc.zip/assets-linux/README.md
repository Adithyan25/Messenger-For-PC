# Linux related assets

- `after-install` and `after-remove` scripts
- `messengerfordesktop.desktop` and icons for launchers

# OS X related assets

- `dmg.json` config file for node-appdmg

# Windows related assets

- `installer.nsi` config file for nsis
